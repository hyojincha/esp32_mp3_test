/*
 * a2dp.h
 *
 *  Created on: 2020. 3. 24.
 *      Author: Owner
 */

#ifndef COMPONENTS_A2DP_A2DP_H_
#define COMPONENTS_A2DP_A2DP_H_


void a2dp_run();


#endif /* COMPONENTS_A2DP_A2DP_H_ */
